import 'package:latlong2/latlong.dart';

class BusStop {
  final int no;
  final String name;
  final LatLng point;
  const BusStop(this.no, this.name, this.point);
}

// IMPORTANT: These are starter coordinates for the UI/prototype.
// Verify each coordinate against a map before production use.
const stops = <BusStop>[
  BusStop(1, 'লাঙ্গলবন্দ', LatLng(23.7187, 90.6227)),
  BusStop(2, 'মালিবাগ', LatLng(23.7110, 90.6245)),
  BusStop(3, 'জাঙ্গাল', LatLng(23.7038, 90.6265)),
  BusStop(4, 'কেওডালা', LatLng(23.6960, 90.6287)),
  BusStop(5, 'মদনপুর', LatLng(23.6868, 90.6307)),
  BusStop(6, 'চেঙাইন', LatLng(23.6790, 90.6340)),
  BusStop(7, 'নাজিমউদ্দিন ভূঁইয়া কলেজ', LatLng(23.6715, 90.6375)),
  BusStop(8, 'ললাটি আন্ডারপাস', LatLng(23.6630, 90.6400)),
  BusStop(9, 'নয়াপুর বাজার', LatLng(23.6545, 90.6430)),
  BusStop(10, 'মিরের টেক', LatLng(23.6460, 90.6465)),
  BusStop(11, 'বস্তল', LatLng(23.6375, 90.6500)),
  BusStop(12, 'গাউসিয়া', LatLng(23.6290, 90.6540)),
  BusStop(13, 'সাওঘাট', LatLng(23.6205, 90.6580)),
  BusStop(14, 'ডহরগাঁও', LatLng(23.6120, 90.6620)),
  BusStop(15, 'ফকির ফ্যাশন', LatLng(23.6035, 90.6660)),
];

const routeName = 'লাঙ্গলবন্দ → ফকির ফ্যাশন';
const appTitle = 'Mahtab Bus Live';
const busId = 'MAHTAB_BUS_01';