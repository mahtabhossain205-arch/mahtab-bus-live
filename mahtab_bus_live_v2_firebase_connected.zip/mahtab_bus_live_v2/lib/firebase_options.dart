// Generated from the Firebase Android app configuration supplied for this project.
// Firebase project: fakir-fashion-bus-maps
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('DefaultFirebaseOptions have not been configured for web.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError('DefaultFirebaseOptions are not configured for this platform.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBZZ5fIcoMfpHB17BH0R06woaPC-9h9aCE',
    appId: '1:317280709605:android:7ef4710fc4a1e5903a1d0c',
    messagingSenderId: '317280709605',
    projectId: 'fakir-fashion-bus-maps',
    databaseURL: 'https://fakir-fashion-bus-maps-default-rtdb.firebaseio.com',
    storageBucket: 'fakir-fashion-bus-maps.firebasestorage.app',
  );
}
