import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'route_data.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await FirebaseAuth.instance.signInAnonymously();
  runApp(const MahtabBusApp());
}

class MahtabBusApp extends StatelessWidget {
  const MahtabBusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: appTitle,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff0757a6)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final mapController = MapController();
  StreamSubscription<Position>? _gpsSub;
  StreamSubscription<DatabaseEvent>? _busSub;
  LatLng? _busPosition;
  bool _driverMode = false;
  bool _tracking = false;
  String _status = 'Live Location বন্ধ';

  DatabaseReference get _busRef =>
      FirebaseDatabase.instance.ref('buses/$busId/location');

  @override
  void initState() {
    super.initState();
    _listenToBus();
  }

  @override
  void dispose() {
    _gpsSub?.cancel();
    _busSub?.cancel();
    super.dispose();
  }

  void _listenToBus() {
    _busSub = _busRef.onValue.listen((event) {
      final data = event.snapshot.value;
      if (data is Map) {
        final lat = (data['lat'] as num?)?.toDouble();
        final lng = (data['lng'] as num?)?.toDouble();
        if (lat != null && lng != null && mounted) {
          setState(() => _busPosition = LatLng(lat, lng));
        }
      }
    });
  }

  Future<void> _startDriverTracking() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      _snack('ফোনের GPS/Location চালু করুন');
      return;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      _snack('Location permission প্রয়োজন');
      return;
    }

    await _gpsSub?.cancel();

    const settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
    );

    _gpsSub = Geolocator.getPositionStream(locationSettings: settings)
        .listen((p) async {
      await _busRef.set({
        'lat': p.latitude,
        'lng': p.longitude,
        'accuracy': p.accuracy,
        'updatedAt': ServerValue.timestamp,
        'driverUid': FirebaseAuth.instance.currentUser?.uid,
      });
      if (mounted) {
        setState(() {
          _busPosition = LatLng(p.latitude, p.longitude);
          _status = 'Live Location চালু';
        });
      }
    });

    setState(() {
      _tracking = true;
      _status = 'Live Location চালু';
    });
  }

  Future<void> _stopDriverTracking() async {
    await _gpsSub?.cancel();
    _gpsSub = null;
    setState(() {
      _tracking = false;
      _status = 'Live Location বন্ধ';
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final routePoints = stops.map((s) => s.point).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(appTitle),
        actions: [
          IconButton(
            tooltip: 'Driver / Passenger',
            onPressed: () => setState(() => _driverMode = !_driverMode),
            icon: Icon(_driverMode ? Icons.drive_eta : Icons.visibility),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
            color: const Color(0xff0757a6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Mahtab Hossain Rifad – Personal Bus Route',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$routeName  •  $_status',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 5,
            child: FlutterMap(
              mapController: mapController,
              options: MapOptions(
                initialCenter: stops[7].point,
                initialZoom: 12.5,
              ),
              children: [
                TileLayer(
                  urlTemplate:
                      'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.mahtab.bus_live',
                ),
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: routePoints,
                      strokeWidth: 5,
                      color: Colors.blue,
                    ),
                  ],
                ),
                MarkerLayer(
                  markers: [
                    ...stops.map(
                      (s) => Marker(
                        point: s.point,
                        width: 48,
                        height: 48,
                        child: Column(
                          children: [
                            Container(
                              width: 27,
                              height: 27,
                              alignment: Alignment.center,
                              decoration: const BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                              ),
                              child: Text(
                                '${s.no}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_busPosition != null)
                      Marker(
                        point: _busPosition!,
                        width: 64,
                        height: 64,
                        child: const Icon(
                          Icons.directions_bus,
                          size: 48,
                          color: Colors.deepOrange,
                        ),
                      ),
                  ],
                ),
                RichAttributionWidget(
                  attributions: const [
                    TextSourceAttribution('OpenStreetMap contributors'),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            flex: 3,
            child: ListView.builder(
              itemCount: stops.length,
              itemBuilder: (context, index) {
                final s = stops[index];
                return ListTile(
                  dense: true,
                  leading: CircleAvatar(
                    radius: 16,
                    child: Text('${s.no}'),
                  ),
                  title: Text(s.name),
                  trailing: index == 0
                      ? const Text('START')
                      : index == stops.length - 1
                          ? const Text('END')
                          : null,
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: _driverMode
          ? FloatingActionButton.extended(
              onPressed:
                  _tracking ? _stopDriverTracking : _startDriverTracking,
              icon: Icon(_tracking ? Icons.stop : Icons.gps_fixed),
              label: Text(_tracking ? 'Tracking বন্ধ' : 'Driver Live'),
            )
          : FloatingActionButton.extended(
              onPressed: _busPosition == null
                  ? null
                  : () => mapController.move(_busPosition!, 15),
              icon: const Icon(Icons.location_searching),
              label: const Text('Bus Location'),
            ),
    );
  }
}