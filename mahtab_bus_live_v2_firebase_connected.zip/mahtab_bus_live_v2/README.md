# Mahtab Bus Live v2 — Real-time Firebase architecture

## What is included
- Driver mode: phone GPS -> Firebase Realtime Database
- Passenger mode: Firebase listener -> live bus marker
- Anonymous Firebase authentication
- 15 stops for the requested route
- OpenStreetMap map
- Driver/Passenger toggle
- Realtime timestamp, accuracy and driver UID fields
- Android location permissions

Route:
লাঙ্গলবন্দ → মালিবাগ → জাঙ্গাল → কেওডালা → মদনপুর → চেঙাইন →
নাজিমউদ্দিন ভূঁইয়া কলেজ → ললাটি আন্ডারপাস → নয়াপুর বাজার → মিরের টেক →
বস্তল → গাউসিয়া → সাওঘাট → ডহরগাঁও → ফকির ফ্যাশন

## Firebase setup (already configured for the supplied Firebase project)
1. Firebase Android configuration is already installed in `android/app/google-services.json`.
2. `lib/firebase_options.dart` has been generated from the supplied Firebase configuration.
3. Firebase Authentication -> Anonymous is enabled.
4. Realtime Database is configured with authenticated read/write rules for `buses/*/location`.
5. Package name: `com.mahtab.bus_live`.
6. Do not replace the Firebase configuration unless you intentionally switch projects.
7. Apply database rules appropriate to your deployment. A development-only
   starting point is shown below; do NOT use open write access in production.

Development example:
{
  "rules": {
    "buses": {
      "$busId": {
        "location": {
          ".read": "auth != null",
          ".write": "auth != null"
        }
      }
    }
  }
}

## Run
flutter pub get
flutter run

## Build
flutter build apk --release

## Important production upgrades
This v2 is the functional architecture, but before public deployment:
- Replace starter stop coordinates with verified coordinates.
- Replace the straight polyline with verified road geometry.
- Add a secure Driver role; do not let every anonymous user write location.
- Add background/foreground service handling for continuous driver tracking.
- Add stale-location indicator and last-updated time.
- Add battery optimization guidance.
- Add server-side validation/rate limits.
- Use Firebase App Check and proper database rules.
- Add a unique bus/driver ID and admin panel if multiple buses are needed.
- Add privacy/consent screens for location sharing.
- Test on the actual driver phone and Android version.

## Data path
`buses/MAHTAB_BUS_01/location`
contains:
lat, lng, accuracy, updatedAt, driverUid