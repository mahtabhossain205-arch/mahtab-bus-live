package com.mahtab.bus_live

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()